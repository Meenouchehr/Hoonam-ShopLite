"""shoplite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions

from app.urls import urlpatterns as app_urls ,view_urls
from ticket.urls import api_urls as ticket_api_urls

from drf_yasg.views import get_schema_view
from drf_yasg import openapi

schima_view = get_schema_view(
    openapi.Info(
        title="ShopLite API",
        default_version='v0',
        description="ShopLite project api ",
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)


urlpatterns = [
    path('admin/', admin.site.urls),
    path('shoplite/core/swagger/',schima_view.with_ui('swagger',cache_timeout=0),name='schema-swagger-ui'),
    path('shoplite/core/redoc/',schima_view.with_ui('redoc',cache_timeout=0),name='schema-redoc'),

    path('shoplite/core/api/',include(app_urls)),
    path('shoplite/core/api/', include(ticket_api_urls)),
    path('shoplite/core/',include(view_urls)),
]

if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

